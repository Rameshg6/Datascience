import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC, LinearSVC
import numpy as np
import pickle

class VisualizeData:
    def __init__(self,data):
        self.data = data
        self.column_names = list(self.data.columns)
        self.target_variable_name = self.column_names[-1]
        self.feature_names = self.column_names[:-1]
    
    def pair_wise_plot(self):
        new_columns = [self.feature_names[i] for i in [3,4]] + [self.target_variable_name]
        new_data_for_plot = self.data.filter(new_columns,axis=1)
        sns.pairplot(new_data_for_plot, hue=self.target_variable_name)
        plt.show()

    def single_feature_plot(self):
        f1_name = 'PEG'
        column_for_f1 = self.data[f1_name]
        target = self.data[self.target_variable_name]
        plt.scatter(column_for_f1,target)
        plt.show()

    def category_wise_visualization(self):
        class_labels = self.data[self.target_variable_name].unique()
        print(class_labels)
        # print(self.data.loc[self.data[' UNS']=='very_low',['STG']])

def read_data():
    data = pd.read_excel('user_knowledge_data.xls', sheet_name = 'Training_Data')
    return data

def apply_knn(data,n):
    y_string = data[' UNS']
    label_string = ['very_low','Low','Middle','High']
    y = []
    for el in y_string:
        index = label_string.index(el)
        y.append(index)
    y = np.array(y)
    X = data.drop([' UNS','STG','SCG','STR','LPR'],axis=1)
    X_tr, X_val, y_tr, y_val = train_test_split(X,y,test_size=0.2, random_state=10)
    # print(X_tr.shape,y_tr.shape,X_val.shape)
    knn_object = KNeighborsClassifier(n_neighbors=n)
    knn_object.fit(X_tr,y_tr)
    y_val_prediction = knn_object.predict(X_val)
    y_tr_prediction = knn_object.predict(X_tr)
    acc = 0
    acc_tr = 0
    for el1,el2 in zip(y_val,y_val_prediction):
        if el1 == el2:
            acc += 1
    for el1,el2 in zip(y_tr,y_tr_prediction):
        if el1 == el2:
            acc_tr += 1
    print('Accuracy:', acc/len(y_val)*100)
    print('Training Accuracy:', acc_tr/len(y_tr)*100)

def apply_LR(data,cost):
    y_string = data[' UNS']
    label_string = ['very_low','Low','Middle','High']
    y = []
    for el in y_string:
        index = label_string.index(el)
        y.append(index)
    y = np.array(y)
    X = data.drop([' UNS','STG','SCG','STR'],axis=1)
    X_tr, X_val, y_tr, y_val = train_test_split(X,y,test_size=0.2, random_state=10)
    # print(X_tr.shape,y_tr.shape,X_val.shape)
    lr_object = LogisticRegression(C=cost)
    lr_object.fit(X_tr,y_tr)
    print('coefficients',lr_object.coef_)
    print('intercept',lr_object.intercept_)
    y_val_prediction = lr_object.predict(X_val)
    y_tr_prediction = lr_object.predict(X_tr)
    acc = 0
    acc_tr = 0
    for el1,el2 in zip(y_val,y_val_prediction):
        if el1 == el2:
            acc += 1
    for el1,el2 in zip(y_tr,y_tr_prediction):
        if el1 == el2:
            acc_tr += 1
    print('Accuracy:', acc/len(y_val)*100)
    print('Training Accuracy:', acc_tr/len(y_tr)*100)
    create_plot_with_decision_surface(X_tr,y_tr,lr_object)
    # TODO: save the model

def apply_SVM(data,cost):
    y_string = data[' UNS']
    label_string = ['very_low','Low','Middle','High']
    y = []
    for el in y_string:
        index = label_string.index(el)
        y.append(index)
    y = np.array(y)
    X = data.drop([' UNS','STG','SCG','STR'],axis=1)
    X_tr, X_val, y_tr, y_val = train_test_split(X,y,test_size=0.2, random_state=10)
    # print(X_tr.shape,y_tr.shape,X_val.shape)
    lr_object = SVC(kernel='rbf',C=100,gamma=0.5)
    lr_object.fit(X_tr,y_tr)
    y_val_prediction = lr_object.predict(X_val)
    y_tr_prediction = lr_object.predict(X_tr)
    acc = 0
    acc_tr = 0
    for el1,el2 in zip(y_val,y_val_prediction):
        if el1 == el2:
            acc += 1
    for el1,el2 in zip(y_tr,y_tr_prediction):
        if el1 == el2:
            acc_tr += 1
    print('Accuracy:', acc/len(y_val)*100)
    print('Training Accuracy:', acc_tr/len(y_tr)*100)
    create_plot_with_decision_surface(X_tr,y_tr,lr_object)
    # TODO: save the model

def apply_saved_model_on_test_data():
    # TODO: load the model and predict on test data
    pass

def make_meshgrid(x, y, h=.02):
    x_min, x_max = x.min() - 1, x.max() + 1
    y_min, y_max = y.min() - 1, y.max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h), np.arange(y_min, y_max, h))
    return xx, yy

def plot_contours(ax, clf, xx, yy, **params):
    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    out = ax.contourf(xx, yy, Z, **params)
    return out

def create_plot_with_decision_surface(X,y,clf):
    fig, ax = plt.subplots()
    # title for the plots
    title = ('Decision surface of linear SVC ')
    # Set-up grid for plotting.
    X0, X1 = X['LPR'], X['PEG']
    xx, yy = make_meshgrid(X0, X1)

    plot_contours(ax, clf, xx, yy, alpha=0.4)
    ax.scatter(X0, X1, c=y, s=20, edgecolors='k')
    ax.set_ylabel('y label here')
    ax.set_xlabel('x label here')
    ax.set_xticks(())
    ax.set_yticks(())
    ax.set_title(title)
    ax.legend()
    plt.show()

if __name__ == '__main__':
    data = read_data()
    visualization_object = VisualizeData(data)
    visualization_object.pair_wise_plot()
    # visualization_object.single_feature_plot()
    # apply_knn(data,n=3)
    # apply_LR(data,cost=1e5)
    # apply_SVM(data,cost=1e6)
    