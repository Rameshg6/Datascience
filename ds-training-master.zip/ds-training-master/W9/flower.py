import os
import numpy as np
import matplotlib.pyplot as plt
import cv2
from keras.models import Sequential
from keras.layers import Conv2D, Flatten, MaxPooling2D, Dense
from sklearn.model_selection import train_test_split

np.random.seed(42)

parent_dir = os.path.join('17flowers/jpg')
dir_list = ['12','14','15']

X = []
y = np.zeros((240,3))
image_names = []
actual_label = []

count = 0
for index,el in enumerate(dir_list):
    sub_dir = os.path.join(parent_dir,el)
    for image_name in os.listdir(sub_dir):
        image = plt.imread(os.path.join(sub_dir,image_name))
        resized_image = cv2.resize(image,(300,300),interpolation = cv2.INTER_AREA)
        X.append(np.array(resized_image))
        y[count,index] = 1
        image_names.append(image_name)
        actual_label.append(el)
        count += 1
X = np.array(X)
print(X.shape,len(image_names))

X_train,X_test,y_train,y_test,im_train,im_test,al_train,al_test = train_test_split(X,y,image_names,actual_label,test_size=0.1)
print(X_train.shape,X_test.shape,y_train.shape,y_test.shape,len(im_train),len(im_test))



def train():
    model = Sequential()
    model.add(Conv2D(5,kernel_size=(9,9),activation='relu',input_shape=(300,300,3)))
    model.add(MaxPooling2D(pool_size=(2,2)))
    model.add(Conv2D(10,kernel_size=(3,3),activation='relu'))
    model.add(MaxPooling2D(pool_size=(2,2)))
    model.add(Conv2D(15,kernel_size=(5,5),activation='relu'))
    model.add(MaxPooling2D(pool_size=(2,2)))
    model.add(Conv2D(20,kernel_size=(3,3),activation='relu'))
    model.add(MaxPooling2D(pool_size=(2,2)))
    model.add(Flatten())
    model.add(Dense(20,activation='relu'))
    model.add(Dense(3,activation='softmax'))
    model.summary()

    model.compile(loss='categorical_crossentropy',optimizer='adam',metrics=['accuracy'])
    model.fit(X_train,y_train,batch_size=18,epochs=25,verbose=1,validation_split=0.1,shuffle=True)

    y_pred = model.predict(X_test)
    label_pred = list(np.argmax(y_pred,axis=1))
    for i in range(0,len(label_pred)):
        if label_pred[i] == 0: label_pred[i] = 12
        if label_pred[i] == 1: label_pred[i] = 14
        if label_pred[i] == 2: label_pred[i] = 15
    for i in range(0,len(label_pred)):
        if (label_pred[i] == al_test[i]):
            continue
        else:
            print(label_pred[i], al_test[i], im_test[i])


train()

# def show_multiple_images():
#     _, grid = plt.subplots(1,2)
#     grid[0].imshow(image)
#     grid[1].imshow(resized_image)
#     plt.show()
    