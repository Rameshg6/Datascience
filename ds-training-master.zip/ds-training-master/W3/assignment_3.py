import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.tree import DecisionTreeClassifier
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC


def read_data():
    data = pd.read_csv('train.csv')
    return data

def visualize_pair_wise(data):
    X = data[['Pclass','Sex','Age']]
    target = data['Survived']
    print(target.shape)
    plt.scatter(X['Age'],X['Pclass'])
    plt.show()

def apply_DT(data):
    y = data['Survived']
    X_old = data[['Pclass','Sex','Embarked']]
    gender_int = []
    for gender in X_old['Sex']:
        if gender == 'male': gender_int.append(0)
        else: gender_int.append(1)
    embarked_int = []
    for e in X_old['Embarked']:
        if e == 'S': embarked_int.append(0)
        elif e == 'Q': embarked_int.append(1)
        elif e == 'C': embarked_int.append(2)
        else: embarked_int.append(3)
    X = np.zeros((len(X_old['Sex']),3))
    X[:,0] = data['Pclass']
    X[:,1] = gender_int
    X[:,2] = embarked_int
    X_tr, X_val, y_tr, y_val = train_test_split(X,y,test_size=0.2, random_state=10)
    print(X_tr.shape,y_tr.shape,X_val.shape)
    dt_object = DecisionTreeClassifier(max_depth=1)
    dt_object.fit(X_tr,y_tr)
    y_val_prediction = dt_object.predict(X_val)
    y_tr_prediction = dt_object.predict(X_tr)
    acc = 0
    acc_tr = 0
    for el1,el2 in zip(y_val,y_val_prediction):
        if el1 == el2:
            acc += 1
    for el1,el2 in zip(y_tr,y_tr_prediction):
        if el1 == el2:
            acc_tr += 1
    print('Accuracy:', acc/len(y_val)*100)
    print('Training Accuracy:', acc_tr/len(y_tr)*100)

def apply_SVM(data):
    y = data['Survived']
    X_old = data[['Pclass','Sex','Embarked']]
    gender_int = []
    for gender in X_old['Sex']:
        if gender == 'male': gender_int.append(0)
        else: gender_int.append(1)
    embarked_int = []
    for e in X_old['Embarked']:
        if e == 'S': embarked_int.append(0)
        elif e == 'Q': embarked_int.append(1)
        elif e == 'C': embarked_int.append(2)
        else: embarked_int.append(3)
    X = np.zeros((len(X_old['Sex']),3))
    X[:,0] = data['Pclass']
    X[:,1] = gender_int
    X[:,2] = embarked_int
    X_tr, X_val, y_tr, y_val = train_test_split(X,y,test_size=0.2, random_state=10)
    print(X_tr.shape,y_tr.shape,X_val.shape)
    dt_object = SVC(C=100,gamma=0.3)
    dt_object.fit(X_tr,y_tr)
    y_val_prediction = dt_object.predict(X_val)
    y_tr_prediction = dt_object.predict(X_tr)
    acc = 0
    acc_tr = 0
    for el1,el2 in zip(y_val,y_val_prediction):
        if el1 == el2:
            acc += 1
    for el1,el2 in zip(y_tr,y_tr_prediction):
        if el1 == el2:
            acc_tr += 1
    print('Accuracy:', acc/len(y_val)*100)
    print('Training Accuracy:', acc_tr/len(y_tr)*100)

if __name__ == '__main__':
    data = read_data()
    # visualize_pair_wise(data)
    apply_DT(data)
    apply_SVM(data)