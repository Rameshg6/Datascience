import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import numpy as np

def read_csv_file():
    tv, radio, np, sales = ([] for i in range(4))
    with open('advertising.csv','r',errors='ignore') as f:
        for line_number,line in enumerate(f):
            if not line_number:
                print(line)
                continue
            values = line.strip().split(',')
            tv.append(values[0])
            radio.append(values[1])
            np.append(values[2])
            sales.append(values[3])
    print(len(tv),len(np),len(radio),len(sales))


def read_csv_file_pandas(filename):
    data = pd.read_csv(filename)
    return data

def eda(data):
    #print(data.head()
    print(data.describe())
    

def visualize(data):
    # tp plot data
    # data.plot(kind="scatter",x="Newspaper",y="Sales")  
    # plt.show()
    
    # To plot 2 features at once
    data.plot(kind="scatter",x="TV",y="Newspaper", c = "Sales", cmap = plt.get_cmap("jet"),colorbar=True)
    plt.show() 


def apply_ML(data):
    X = np.array(data[['TV','Newspaper','Radio']])
    y = np.array(data['Sales'])
    print(X.shape,y.shape)

    linear_regressor = LinearRegression()
    linear_regressor.fit(X,y)
    print(linear_regressor.score(X,y))
    weights = linear_regressor.coef_
    weights.dump('wt.dat')
    print(linear_regressor.intercept_)

    new_ip = np.array([500,100,1000]).reshape(1,-1)
    print(linear_regressor.predict(new_ip))



if __name__ == '__main__':
    # read_csv_file()  
    data = read_csv_file_pandas('advertising.csv')
    # visualize(data)
    apply_ML(data)